#include "sema.h"
#include "symbol.h"

TypePtr GlobalFunctionReturnType4ReturnInStmt;

void semaHandleVarDec4FunctionDeclare(struct node_t *des, TypePtr paramTypePtr, TypePtr funcTypePtr);

void semaHandleDefList4CompSt(struct node_t *des);

void semaHandleDef4CompSt(Node *pNode);

void semaHandleDecList4CompSt(Node *pNode, TypePtr pType_);

void semaHandleDec4CompSt(Node *des, TypePtr specifier);

void semaHandleVarDec4CompSt(Node *des, TypePtr specifier);

void semaHandleProgram(Node *des)
{
	// fprintf(stderr, "------semaHandleProgram-------\n");
	if (des->children[0]->enumNodeType == ENUM_SYN_ExtDefList)
	{
		assert(des->nrChildren == 1);
		semaHandleExtDefList(des->children[0]);
	}
	else
	{
		assert(0);
	}
}
void semaHandleExtDefList(Node *des)
{
	// fprintf(stderr, "------semaHandleExtDefList-------\n");
	if (des->nrChildren == 0)
	{ // epsilon
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_ExtDef && des->children[1]->enumNodeType == ENUM_SYN_ExtDefList)
	{
		assert(des->nrChildren == 2);
		semaHandleExtDef(des->children[0]);
		semaHandleExtDefList(des->children[1]);
	}
	else
	{
		assert(0);
	}
}
void semaHandleExtDef(Node *des)
{
	// fprintf(stderr, "-------semaHandleExtDef------\n");
	if (des->children[0]->enumNodeType == ENUM_SYN_Specifier && des->children[1]->enumNodeType == ENUM_SYN_ExtDecList && des->children[2]->enumNodeType == ENUM_LEX_SEMI)
	{
		assert(des->nrChildren == 3);
		TypePtr specifier = semaHandleSpecifier(des->children[0]);
		semaHandleExtDecList(des->children[1], specifier);
		// semaHandlesema(des->children[2]);
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_Specifier && des->children[1]->enumNodeType == ENUM_LEX_SEMI)
	{
		assert(des->nrChildren == 2);
		semaHandleSpecifier(des->children[0]);
		// semaHandlesema(des->children[1]);
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_Specifier && des->children[1]->enumNodeType == ENUM_SYN_FunDec && des->children[2]->enumNodeType == ENUM_SYN_CompSt)
	{
		assert(des->nrChildren == 3);
		TypePtr retType = semaHandleSpecifier(des->children[0]);
		GlobalFunctionReturnType4ReturnInStmt = retType;
		TypePtr functionTypePtr = (TypePtr)malloc(sizeof(Type_));
		functionTypePtr->kind = FUNCTION;
		functionTypePtr->function.retType = retType;

		semaHandleFunDec4Define(des->children[1], functionTypePtr);
		semaHandleCompSt(des->children[2]);
	}
	else
	{
		assert(0);
	}
}

void semaHandleVarDec4ExtDecList(Node *des, TypePtr specifier)
{

	// fprintf(stderr, "------semaHandleVarDec4ExtDecList-------\n");
	if (des->children[0]->enumNodeType == ENUM_LEX_ID)
	{
		assert(des->nrChildren == 1);
		if(!insertSymbol(des->children[0]->tokenval, specifier)){
			fprintf(stdout, "Error type 3 at Line %d: Redefined global variable \"%s\".\n", des->lineno, des->children[0]->tokenval);
		}

	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_VarDec && des->children[1]->enumNodeType == ENUM_LEX_LB && des->children[2]->enumNodeType == ENUM_LEX_INT && des->children[3]->enumNodeType == ENUM_LEX_RB)
	{
		assert(des->nrChildren == 4);
		TypePtr arrayPtr = (TypePtr)malloc(sizeof(Type_));
		arrayPtr->array.elem = specifier;
		arrayPtr->array.size = des->children[2]->intval;
		arrayPtr->kind = ARRAY;
		semaHandleVarDec4ExtDecList(des->children[0], arrayPtr);
		assert(0);
	}
	else
	{
		assert(0);
	}
}

void semaHandleExtDecList(Node *des, TypePtr specifier)
{
	// fprintf(stderr, "------semaHandleExtDecList-------\n");
	if (des->children[0]->enumNodeType == ENUM_SYN_VarDec)
	{
		assert(des->nrChildren == 1);
		semaHandleVarDec4ExtDecList(des->children[0], specifier);
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_VarDec && des->children[1]->enumNodeType == ENUM_LEX_COMMA && des->children[2]->enumNodeType == ENUM_SYN_ExtDecList)
	{
		assert(des->nrChildren == 3);
		semaHandleVarDec4ExtDecList(des->children[0], specifier);
		// semaHandleCOMMA(des->children[1]);
		semaHandleExtDecList(des->children[2], specifier);
	}
	else
	{
		assert(0);
	}
}
TypePtr semaHandleSpecifier(Node *des)
{
	// fprintf(stderr, "------semaHandleSpecifier-------\n");
	TypePtr specifier = (TypePtr)malloc(sizeof(Type_));
	specifier->structure = (FieldListPtr)malloc(sizeof(FieldList_));
	if (des->children[0]->enumNodeType == ENUM_LEX_TYPE)
	{
		assert(des->nrChildren == 1);
		specifier->kind = BASIC;
		specifier->basic = strcmp(des->children[0]->tokenval, "int") == 0 ? BASIC_INT : BASIC_FLOAT;
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_StructSpecifier)
	{
		assert(des->nrChildren == 1);
		specifier->kind = STRUCTURE;
		semaHandleStructSpecifier(des->children[0], specifier);
	}
	else
	{
		assert(0);
	}
	return specifier;
}
void semaHandleStructSpecifier(Node *des, TypePtr specifier)
{
	// fprintf(stderr, "-----semaHandleStructSpecifier--------\n");
	if (des->children[0]->enumNodeType == ENUM_LEX_STRUCT && des->children[1]->enumNodeType == ENUM_SYN_OptTag &&
		des->children[2]->enumNodeType == ENUM_LEX_LC && des->children[3]->enumNodeType == ENUM_SYN_DefList && des->children[4]->enumNodeType == ENUM_LEX_RC)
	{
		assert(des->nrChildren == 5);
		if (!semaHandleOptTag(des->children[1], specifier))
			fprintf(stdout, "Error type 16 at Line %d: Redefined structure \"%s\".\n", des->lineno, des->children[1]->children[0]->tokenval);
		semaHandleDefList4Struct(des->children[3], specifier);
	}
	else if (des->children[0]->enumNodeType == ENUM_LEX_STRUCT && des->children[1]->enumNodeType == ENUM_SYN_Tag)
	{
		assert(des->nrChildren == 2);
		// semaHandleSTRUCT(des->children[0]);
		semaHandleTag(des->children[1], specifier);
	}
	else
	{
		assert(0);
	}
}
bool semaHandleOptTag(Node *des, TypePtr specifier)
{
	// fprintf(stderr, "------semaHandleOptTag-------------\n");
	if (des->children[0]->enumNodeType == ENUM_LEX_ID)
	{
		assert(des->nrChildren == 1);
		// semaHandleID(des->children[0]);
		char *id = des->children[0]->tokenval;
		//		fprintf(stderr,"------------%s---------------\n",id);
		FieldListPtr symbol = searchSymbol(id);
		if (symbol != NULL)
		{
			return false;
		}
		else
		{
			// insert symbal
			if (!insertSymbol(des->children[0]->tokenval, specifier))
			{
				return false;
			}
		}
	}
	else if (des->nrChildren == 0)
	{ // epsilon
	}
	else
	{
		assert(0);
	}
	return true;
}
void semaHandleTag(Node *des, TypePtr specifier)
{
	// fprintf(stderr, "------semaHandleTag-------\n");
	if (des->children[0]->enumNodeType == ENUM_LEX_ID)
	{
		assert(des->nrChildren == 1);
		// semaHandleID(des->children[0]);
		char *id = des->children[0]->tokenval;
		SymbolPtr symbol = searchSymbol(id);
		if (symbol == NULL)
		{
			printf("Error type 17 at Line %d: Undefined structure \"%s\".\n", des->lineno, id);
			*specifier=_ERROR_TYPE;
		}else{
			*specifier=*symbol->type;
		}
	}
	else
	{
		assert(0);
	}
}
void semaHandleVarDec4Struct(Node *des, TypePtr subfieldType, TypePtr structSpecifier)
{
	// fprintf(stderr, "------semaHandleVarDec4Struct-------\n");
	if (des->children[0]->enumNodeType == ENUM_LEX_ID)
	{
		assert(des->nrChildren == 1);
		// add "subfieldType des->children[0](ID);" to structSpecifier
		assert(structSpecifier->kind == STRUCTURE);

		FieldListPtr field = (FieldListPtr)malloc(sizeof(FieldList_));
		// TODO : need check duplicated name
		field->name = des->children[0]->tokenval;
		field->next = NULL;
		field->type = subfieldType;
		if (searchSymbol(field->name))
		{
			fprintf(stdout, "Error type 15 at Line %d: Redefine field \"%s\" in struct.\n", des->lineno, des->children[0]->tokenval);
			free(field);
		}

		if (structSpecifier->structure->head == NULL)
		{
			structSpecifier->structure->head = field;
		}
		else
		{
			field->next = structSpecifier->structure->head;
			structSpecifier->structure->head = field;
		}
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_VarDec && des->children[1]->enumNodeType == ENUM_LEX_LB && des->children[2]->enumNodeType == ENUM_LEX_INT && des->children[3]->enumNodeType == ENUM_LEX_RB)
	{
		assert(des->nrChildren == 4);
		TypePtr arrayPtr = (TypePtr)malloc(sizeof(Type_));
		arrayPtr->array.elem = subfieldType;
		arrayPtr->array.size = des->children[2]->intval;
		arrayPtr->kind = ARRAY;
		semaHandleVarDec4FunctionDeclare(des->children[0], arrayPtr, structSpecifier);
	}
	else
	{
		assert(0);
	}
}
void semaHandleFunDec4Define(struct node_t *des, TypePtr functionTypePtr)
{
	// fprintf(stderr, "-------semaHandleFunDec4Define------\n");
	if (des->nrChildren == 4 && des->children[0]->enumNodeType == ENUM_LEX_ID && des->children[1]->enumNodeType == ENUM_LEX_LP && des->children[2]->enumNodeType == ENUM_SYN_VarList && des->children[3]->enumNodeType == ENUM_LEX_RP)
	{
		functionTypePtr->function.nrParams = 0;
		semaHandleVarList(des->children[2], functionTypePtr);
		if(!insertSymbol(des->children[0]->tokenval, functionTypePtr))
			fprintf(stdout, "Error type 4 at Line %d: Redefined function name \"%s\".\n", des->lineno, des->children[0]->tokenval);
	}
	else if (des->nrChildren == 3 && des->children[0]->enumNodeType == ENUM_LEX_ID && des->children[1]->enumNodeType == ENUM_LEX_LP && des->children[2]->enumNodeType == ENUM_LEX_RP)
	{
		functionTypePtr->function.nrParams = 0;
		functionTypePtr->function.params = NULL;
		if(!insertSymbol(des->children[0]->tokenval, functionTypePtr))
			fprintf(stdout, "Error type 4 at Line %d: Redefined function name \"%s\".\n", des->lineno, des->children[0]->tokenval);
	}
	else
	{
		assert(0);
	}
}
void semaHandleVarList(struct node_t *des, TypePtr funTypePtr)
{
	// fprintf(stderr, "------semaHandleVarList-------\n");
	if (des->nrChildren == 1 && des->children[0]->enumNodeType == ENUM_SYN_ParamDec)
	{
		assert(des->nrChildren == 1);
		semaHandleParamDec(des->children[0], funTypePtr);
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_ParamDec && des->children[1]->enumNodeType == ENUM_LEX_COMMA && des->children[2]->enumNodeType == ENUM_SYN_VarList)
	{
		assert(des->nrChildren == 3);
		semaHandleParamDec(des->children[0], funTypePtr);
		semaHandleVarList(des->children[2], funTypePtr);
	}
	else
	{
		assert(0);
	}
}
void semaHandleParamDec(struct node_t *des, TypePtr funcTypePtr)
{
	// fprintf(stderr, "------semaHandleParamDec-------\n");
	if (des->children[0]->enumNodeType == ENUM_SYN_Specifier && des->children[1]->enumNodeType == ENUM_SYN_VarDec)
	{

		assert(des->nrChildren == 2);
		TypePtr typePtr = semaHandleSpecifier(des->children[0]);
		semaHandleVarDec4FunctionDeclare(des->children[1], typePtr, funcTypePtr);
		// count nr of parameters
		funcTypePtr->function.nrParams++;
	}
	else
	{
		assert(0);
	}
}

void semaHandleVarDec4FunctionDeclare(struct node_t *des, TypePtr paramTypePtr, TypePtr funcTypePtr)
{
	// fprintf(stderr, "------semaHandleVarDec4FunctionDeclare-------\n");
	if (des->children[0]->enumNodeType == ENUM_LEX_ID)
	{
		assert(des->nrChildren == 1);
		// add "subfieldType des->children[0](ID);" to specifier
		assert(funcTypePtr->kind == FUNCTION);

		FieldListPtr field = (FieldListPtr)malloc(sizeof(FieldList_));
		// TODO : need check duplicated name
		field->name = des->children[0]->tokenval;
		field->next = NULL;
		field->type = paramTypePtr;
		if (searchSymbol(field->name))
		{
			fprintf(stdout, "Error type 3 at Line %d: Redefined function param \"%s\".\n", des->lineno, des->children[0]->tokenval);
		}

		if (funcTypePtr->function.params == NULL)
		{
			funcTypePtr->function.params = field;
		}
		else
		{
			field->next = funcTypePtr->function.params;
			funcTypePtr->function.params = field;
		}
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_VarDec && des->children[1]->enumNodeType == ENUM_LEX_LB && des->children[2]->enumNodeType == ENUM_LEX_INT && des->children[3]->enumNodeType == ENUM_LEX_RB)
	{
		assert(des->nrChildren == 4);
		TypePtr arrayPtr = (TypePtr)malloc(sizeof(Type_));
		arrayPtr->array.elem = paramTypePtr;
		arrayPtr->array.size = des->children[2]->intval;
		arrayPtr->kind = ARRAY;
		semaHandleVarDec4FunctionDeclare(des->children[0], arrayPtr, funcTypePtr);
	}
	else
	{
		assert(0);
	}
}

void semaHandleCompSt(Node *des)
{
	//fprintf(stderr, "------semaHandleCompSt-------\n");
	if (des->children[0]->enumNodeType == ENUM_LEX_LC && des->children[1]->enumNodeType == ENUM_SYN_DefList && des->children[2]->enumNodeType == ENUM_SYN_StmtList && des->children[3]->enumNodeType == ENUM_LEX_RC)
	{
		assert(des->nrChildren == 4);
		// semaHandleLC(des->children[0]);
		semaHandleDefList4CompSt(des->children[1]);
		semaHandleStmtList(des->children[2]);
		// semaHandleRC(des->children[3]);
	}
	else
	{
		assert(0);
	}
}

void semaHandleDefList4CompSt(Node *des) {
	// fprintf(stderr, "------semaHandleDefList4CompSt-------\n");
	if (des->nrChildren == 0)
	{ // epsilon
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_Def && des->children[1]->enumNodeType == ENUM_SYN_DefList)
	{
		assert(des->nrChildren == 2);
		semaHandleDef4CompSt(des->children[0]);
		semaHandleDefList4CompSt(des->children[1]);
	}
	else
	{
		assert(0);
	}
}

void semaHandleDef4CompSt(Node *des) {
	assert(des->nrChildren==3);
	TypePtr specifier=semaHandleSpecifier(des->children[0]);
	semaHandleDecList4CompSt(des->children[1],specifier);
}

void semaHandleDecList4CompSt(Node *des, TypePtr specifier) {
	// fprintf(stderr, "-----semaHandleDecList4CompSt--------\n");
	if (des->nrChildren != 1 && des->children[0]->enumNodeType == ENUM_SYN_Dec && des->children[1]->enumNodeType == ENUM_LEX_COMMA && des->children[2]->enumNodeType == ENUM_SYN_DecList)
	{
		assert(des->nrChildren == 3);
		semaHandleDec4CompSt(des->children[0],  specifier);
		semaHandleDecList4CompSt(des->children[2], specifier);
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_Dec)
	{
		assert(des->nrChildren == 1);
		semaHandleDec4CompSt(des->children[0], specifier);
	}
	else
	{
		assert(0);
	}
}

void semaHandleDec4CompSt(Node *des, TypePtr specifier) {
	// fprintf(stderr, "------semaHandleDec4CompSt-------\n");
	semaHandleVarDec4CompSt(des->children[0], specifier);
}

void semaHandleVarDec4CompSt(Node *des, TypePtr specifier) {
	// fprintf(stderr, "------semaHandleVarDec4CompSt-------\n");
	if (des->children[0]->enumNodeType == ENUM_LEX_ID)
	{
		assert(des->nrChildren == 1);
		// add "subfieldType des->children[0](ID);" to structSpecifier
		if (searchSymbol(des->children[0]->tokenval))
		{
			fprintf(stdout, "Error type 3 at Line %d: Redefined variable \"%s\".\n", des->lineno, des->children[0]->tokenval);
		}
		else{
			if(specifier->kind==ERROR)
				return ;
			assert(insertSymbol(des->children[0]->tokenval,specifier));
		}

	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_VarDec && des->children[1]->enumNodeType == ENUM_LEX_LB && des->children[2]->enumNodeType == ENUM_LEX_INT && des->children[3]->enumNodeType == ENUM_LEX_RB)
	{
		assert(des->nrChildren == 4);
		TypePtr arrayPtr = (TypePtr)malloc(sizeof(Type_));
		arrayPtr->array.elem = specifier;
		arrayPtr->array.size = des->children[2]->intval;
		arrayPtr->kind = ARRAY;
		semaHandleVarDec4CompSt(des->children[0], arrayPtr);
	}
	else
	{
		assert(0);
	}
}

void semaHandleStmtList(Node *des)
{
	// fprintf(stderr, "------semaHandleStmtList-------\n");
	if (des->nrChildren == 0)
	{ // epsilon
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_Stmt && des->children[1]->enumNodeType == ENUM_SYN_StmtList)
	{
		assert(des->nrChildren == 2);
		semaHandleStmt(des->children[0]);
		semaHandleStmtList(des->children[1]);
	}
	else
	{
		assert(0);
	}
}
void semaHandleStmt(Node *des)
{
	// fprintf(stderr, "-------semaHandleStmt------\n");
	if (des->children[0]->enumNodeType == ENUM_SYN_Exp && des->children[1]->enumNodeType == ENUM_LEX_SEMI)
	{
		assert(des->nrChildren == 2);
		semaHandleExp(des->children[0]);
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_CompSt)
	{
		assert(des->nrChildren == 1);
		semaHandleCompSt(des->children[0]);
	}
	else if (des->children[0]->enumNodeType == ENUM_LEX_RETURN && des->children[1]->enumNodeType == ENUM_SYN_Exp && des->children[2]->enumNodeType == ENUM_LEX_SEMI)
	{
		assert(des->nrChildren == 3);
		// semaHandleRETURN(des->children[0]);
		TypePtr retType = semaHandleExp(des->children[1]);
		if(!typeEqual(retType,GlobalFunctionReturnType4ReturnInStmt)){
			fprintf(stdout, "Error type 8 at Line %d: return type is not matched.\n", des->lineno);
		}
		// semaHandlesema(des->children[2]);
	}
	else if (des->children[0]->enumNodeType == ENUM_LEX_IF && des->children[1]->enumNodeType == ENUM_LEX_LP && des->children[2]->enumNodeType == ENUM_SYN_Exp && des->children[3]->enumNodeType == ENUM_LEX_RP && des->children[4]->enumNodeType == ENUM_SYN_Stmt)
	{
		assert(des->nrChildren == 5);
		// semaHandleIF(des->children[0]);
		// semaHandleLP(des->children[1]);
		semaHandleExp(des->children[2]);
		// semaHandleRP(des->children[3]);
		semaHandleStmt(des->children[4]);
	}
	else if (des->children[0]->enumNodeType == ENUM_LEX_IF && des->children[1]->enumNodeType == ENUM_LEX_LP && des->children[2]->enumNodeType == ENUM_SYN_Exp && des->children[3]->enumNodeType == ENUM_LEX_RP && des->children[4]->enumNodeType == ENUM_SYN_Stmt && des->children[5]->enumNodeType == ENUM_LEX_ELSE && des->children[6]->enumNodeType == ENUM_SYN_Stmt)
	{
		assert(des->nrChildren == 7);
		// semaHandleIF(des->children[0]);
		// semaHandleLP(des->children[1]);
		semaHandleExp(des->children[2]);
		// semaHandleRP(des->children[3]);
		semaHandleStmt(des->children[4]);
		// semaHandleELSE(des->children[5]);
		semaHandleStmt(des->children[6]);
	}
	else if (des->children[0]->enumNodeType == ENUM_LEX_WHILE && des->children[1]->enumNodeType == ENUM_LEX_LP && des->children[2]->enumNodeType == ENUM_SYN_Exp && des->children[3]->enumNodeType == ENUM_LEX_RP && des->children[4]->enumNodeType == ENUM_SYN_Stmt)
	{
		assert(des->nrChildren == 5);
		// semaHandleWHILE(des->children[0]);
		// semaHandleLP(des->children[1]);
		semaHandleExp(des->children[2]);
		// semaHandleRP(des->children[3]);
		semaHandleStmt(des->children[4]);
	}
	else
	{
		assert(0);
	}
}
void semaHandleDefList4Struct(Node *des, TypePtr specifier)
{
	// fprintf(stderr, "------semaHandleDefList4Struct-------\n");
	// assert(0);
	if (des->nrChildren == 0)
	{ // epsilon
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_Def && des->children[1]->enumNodeType == ENUM_SYN_DefList)
	{
		assert(des->nrChildren == 2);
		semaHandleDef4Struct(des->children[0], specifier);
		semaHandleDefList4Struct(des->children[1], specifier);
	}
	else
	{
		assert(0);
	}
}

// void addSubfield2Structure(TypePtr subfield,)

void semaHandleDef4Struct(Node *des, TypePtr specifier)
{
	// fprintf(stderr, "------semaHandleDef4Struct-------\n");
	if (des->children[0]->enumNodeType == ENUM_SYN_Specifier && des->children[1]->enumNodeType == ENUM_SYN_DecList && des->children[2]->enumNodeType == ENUM_LEX_SEMI)
	{
		assert(des->nrChildren == 3);
		// get the type recursively
		TypePtr subfieldType = semaHandleSpecifier(des->children[0]);
		// add subfield to specifier
		semaHandleDecList4Struct(des->children[1], subfieldType, specifier);
	}
	else
	{
		assert(0);
	}
}

// add subfieldType variables to specifier
void semaHandleDecList4Struct(Node *des, TypePtr subfieldType, TypePtr specifier)
{
	// fprintf(stderr, "-----semaHandleDecList4Struct--------\n");
	if (des->nrChildren != 1 && des->children[0]->enumNodeType == ENUM_SYN_Dec && des->children[1]->enumNodeType == ENUM_LEX_COMMA && des->children[2]->enumNodeType == ENUM_SYN_DecList)
	{
		assert(des->nrChildren == 3);
		semaHandleDec4Struct(des->children[0], subfieldType, specifier);
		semaHandleDecList4Struct(des->children[2], subfieldType, specifier);
	}
	else if (des->children[0]->enumNodeType == ENUM_SYN_Dec)
	{
		assert(des->nrChildren == 1);
		semaHandleDec4Struct(des->children[0], subfieldType, specifier);
	}
	else
	{
		assert(0);
	}
}
void semaHandleDec4Struct(Node *des, TypePtr subfieldType, TypePtr specifier)
{
	// fprintf(stderr, "------semaHandleDec4Struct-------\n");
	semaHandleVarDec4Struct(des->children[0], subfieldType, specifier);
}
TypePtr semaHandleExp(Node *des)
{
	// fprintf(stderr, "-------semaHandleExp------\n");
	if (des->nrChildren == 3&&des->children[0]->enumNodeType == ENUM_SYN_Exp && des->children[1]->enumNodeType == ENUM_LEX_ASSIGNOP && des->children[2]->enumNodeType == ENUM_SYN_Exp)
	{
		TypePtr type1=semaHandleExp(des->children[0]);
		TypePtr type2=semaHandleExp(des->children[2]);
		Node *temp = des->children[0];
		//left-hand varibale
		if(!(temp->nrChildren == 1&&temp->children[0]->enumNodeType == ENUM_LEX_ID \
		   ||temp->nrChildren == 4&&temp->children[0]->enumNodeType == ENUM_SYN_Exp && temp->children[1]->enumNodeType == ENUM_LEX_LB && temp->children[2]->enumNodeType == ENUM_SYN_Exp && temp->children[3]->enumNodeType == ENUM_LEX_RB\
		   ||temp->nrChildren == 3&&temp->children[0]->enumNodeType == ENUM_SYN_Exp && temp->children[1]->enumNodeType == ENUM_LEX_DOT && temp->children[2]->enumNodeType == ENUM_LEX_ID))
		{
			fprintf(stdout, "Error type 6 at Line %d: The left-hand side of an assignment must be a variable\n", des->lineno);
		}
		if(!typeEqual(type1, type2))
			fprintf(stdout, "Error type 5 at Line %d: EXP near '=' is type unmatched\n", des->lineno);

		return type1;
	}
	else if (
			des->nrChildren == 3&&(
			des->children[0]->enumNodeType == ENUM_SYN_Exp && des->children[1]->enumNodeType == ENUM_LEX_RELOP && des->children[2]->enumNodeType == ENUM_SYN_Exp\
 		  || des->children[0]->enumNodeType == ENUM_SYN_Exp && des->children[1]->enumNodeType == ENUM_LEX_PLUS && des->children[2]->enumNodeType == ENUM_SYN_Exp\
		  || des->children[0]->enumNodeType == ENUM_SYN_Exp && des->children[1]->enumNodeType == ENUM_LEX_MINUS && des->children[2]->enumNodeType == ENUM_SYN_Exp\
		  || des->children[0]->enumNodeType == ENUM_SYN_Exp && des->children[1]->enumNodeType == ENUM_LEX_STAR && des->children[2]->enumNodeType == ENUM_SYN_Exp\
		  || des->children[0]->enumNodeType == ENUM_SYN_Exp && des->children[1]->enumNodeType == ENUM_LEX_DIV && des->children[2]->enumNodeType == ENUM_SYN_Exp)
			)
	{
		TypePtr type1 = semaHandleExp(des->children[0]);
		TypePtr type2 = semaHandleExp(des->children[2]);
		if(!typeEqual(type1, type2) || type1->kind!=BASIC)
			fprintf(stdout, "Error type 7 at Line %d: +,-,*,/,RELOP type mismatch \"%s\".\n", des->lineno, des->children[1]->tokenval);
		return type1;
	}
	else if(des->nrChildren == 3&&
			(des->children[0]->enumNodeType == ENUM_SYN_Exp && des->children[1]->enumNodeType == ENUM_LEX_AND && des->children[2]->enumNodeType == ENUM_SYN_Exp\
          || des->children[0]->enumNodeType == ENUM_SYN_Exp && des->children[1]->enumNodeType == ENUM_LEX_OR && des->children[2]->enumNodeType == ENUM_SYN_Exp)
			)
	{
		TypePtr type1 = semaHandleExp(des->children[0]);
		TypePtr type2 = semaHandleExp(des->children[2]);
		if(!typeEqual(type1, type2) || type1->kind!=BASIC || type1->basic==BASIC_INT)
			fprintf(stdout, "Error type 7 at Line %d: &&,|| type mismatch \"%s\".\n", des->lineno, des->children[1]->tokenval);
		return type1;
	}
	else if (des->nrChildren == 3&&des->children[0]->enumNodeType == ENUM_LEX_LP && des->children[1]->enumNodeType == ENUM_SYN_Exp && des->children[2]->enumNodeType == ENUM_LEX_RP)
	{
		return semaHandleExp(des->children[1]);
	}
	else if (des->nrChildren == 2&&des->children[0]->enumNodeType == ENUM_LEX_MINUS && des->children[1]->enumNodeType == ENUM_SYN_Exp)
	{
		TypePtr type1 = semaHandleExp(des->children[1]);
		if(type1->kind!=BASIC)
			fprintf(stdout, "Error type 7 at Line %d: - type mismatch \"%s\".\n", des->lineno, des->children[1]->tokenval);
		return type1;
	}
	else if (des->nrChildren == 2&&des->children[0]->enumNodeType == ENUM_LEX_NOT && des->children[1]->enumNodeType == ENUM_SYN_Exp)
	{
		TypePtr type1 = semaHandleExp(des->children[1]);
		if(type1->kind!=BASIC || type1->basic==BASIC_INT)
			fprintf(stdout, "Error type 7 at Line %d: ! type mismatch \"%s\".\n", des->lineno, des->children[1]->tokenval);
		return type1;
	}
	else if (des->nrChildren == 4&&des->children[0]->enumNodeType == ENUM_LEX_ID && des->children[1]->enumNodeType == ENUM_LEX_LP && des->children[2]->enumNodeType == ENUM_SYN_Args && des->children[3]->enumNodeType == ENUM_LEX_RP)
	{
		SymbolPtr func=searchSymbol(des->children[0]->tokenval);
		if(NULL==func){
			fprintf(stdout, "Error type 2 at Line %d: Undefined function \"%s\".\n", des->lineno, des->children[0]->tokenval);
			return ERROR_TYPE;
		}
		else if(func->type->kind!=FUNCTION){
            fprintf(stdout, "Error type 11 at Line %d: \"%s\" is not callable.\n", des->lineno, des->children[0]->tokenval);
		    return ERROR_TYPE;
		}
		semaHandleArgsWrapper(des->children[2], func->type->function.params,func->type->function.nrParams);
		return func->type->function.retType;
	}
	else if (des->nrChildren == 3&&des->children[0]->enumNodeType == ENUM_LEX_ID && des->children[1]->enumNodeType == ENUM_LEX_LP && des->children[2]->enumNodeType == ENUM_LEX_RP)
	{
		SymbolPtr func=searchSymbol(des->children[0]->tokenval);
		if(NULL==func){
			fprintf(stdout, "Error type 2 at Line %d: Undefined function \"%s\".\n", des->lineno, des->children[0]->tokenval);
			return ERROR_TYPE;
		}
        else if(func->type->kind!=FUNCTION){
            fprintf(stdout, "Error type 11 at Line %d: \"%s\" is not callable.\n", des->lineno, des->children[0]->tokenval);
        }
		else if (func->type->function.nrParams!=0){
			fprintf(stdout, "Error type 9 at Line %d: Function parameters unmatch:\"%s\".\n", des->lineno, des->children[0]->tokenval);
			return func->type->function.retType;
		}
		return func->type->function.retType;

	}
	else if (des->nrChildren == 4&&des->children[0]->enumNodeType == ENUM_SYN_Exp && des->children[1]->enumNodeType == ENUM_LEX_LB && des->children[2]->enumNodeType == ENUM_SYN_Exp && des->children[3]->enumNodeType == ENUM_LEX_RB)
	{
		TypePtr type1 = semaHandleExp(des->children[0]);
		TypePtr type2 = semaHandleExp(des->children[2]);
		if(type1->kind!=ARRAY)
			fprintf(stdout, "Error type 10 at Line %d: element before [] is not array.\n", des->lineno);
		if(type2->kind!=BASIC || type2->basic != BASIC_INT)
			fprintf(stdout, "Error type 12 at Line %d: element in [] is not INT.\n", des->lineno);
		return type1->array.elem;
	}
	else if (des->nrChildren == 3&&des->children[0]->enumNodeType == ENUM_SYN_Exp && des->children[1]->enumNodeType == ENUM_LEX_DOT && des->children[2]->enumNodeType == ENUM_LEX_ID)
	{
		TypePtr type = semaHandleExp(des->children[0]);
		if(type->kind!=STRUCTURE)
		{
			fprintf(stdout, "Error type 13 at Line %d: element before . is not struct.\n", des->lineno);
			return ERROR_TYPE;
		}
		FieldListPtr searchResult=searchStructByNameInOneDepth(des->children[2]->tokenval,type);
		if(NULL==searchResult){
			fprintf(stdout, "Error type 14 at Line %d: Visit undefined filed in struct.\n", des->lineno);
			return ERROR_TYPE;;
		}
		return searchResult->type;
	}
	else if (des->nrChildren == 1&&des->children[0]->enumNodeType == ENUM_LEX_ID)
	{
		SymbolPtr a=searchSymbol(des->children[0]->tokenval);
		if(NULL==a){
			fprintf(stdout, "Error type 1 at Line %d: Undefined variable.\n", des->lineno);
			return ERROR_TYPE;
		}
		return a->type;

	}
	else if (des->nrChildren == 1&&des->children[0]->enumNodeType == ENUM_LEX_INT)
	{
		return INT_TYPE;
	}
	else if (des->nrChildren == 1&&des->children[0]->enumNodeType == ENUM_LEX_FLOAT)
	{
		return FLOAT_TYPE;
	}
	else
	{
		assert(0);
	}
	return ERROR_TYPE;
}

/*
 * fprintf(stdout, "Error type 9 at Line %d: ! Function parameters unmatch:\"%s\".\n", des->lineno, tempDes->children[0]->tokenval);
*/
void semaHandleArgsWrapper(Node *des, FieldListPtr params,int nrParams) {
    // fprintf(stderr, "-------semaHandleArgsWrapper------\n");
	// arg1 arg2 arg3
	FieldListPtr* restoreParams=(FieldListPtr*)malloc(sizeof(FieldListPtr)*nrParams);
	for(int i=nrParams-1;i>=0;i--){
		restoreParams[i]=params;
		params=params->next;
	}
	semaHandleArgs(des, restoreParams, 0,nrParams);
}


void semaHandleArgs(Node *des, FieldListPtr * params, int i,int nrParams){
    // fprintf(stderr, "-------semaHandleArgs------\n");
	if(i==nrParams)
	{
		//require < input
		fprintf(stdout, "Error type 9 at Line %d: Function parameters not match\n", des->lineno);
		return ;
	}
	TypePtr typePtr1=semaHandleExp(des->children[0]);
	TypePtr typePtr2=params[i]->type;
	if(!typeEqual(typePtr1,typePtr2))
		fprintf(stdout, "Error type 9 at Line %d: Function parameters not match\n", des->lineno);

	if(des->nrChildren==1)
	{
		if(i+1<nrParams)
			fprintf(stdout, "Error type 9 at Line %d: Function parameters not match\n", des->lineno);
	}
	else if(des->nrChildren==3)
		semaHandleArgs(des->children[2],params,i+1,nrParams);
	else
		assert(0);
}


