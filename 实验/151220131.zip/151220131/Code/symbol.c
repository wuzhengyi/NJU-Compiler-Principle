#include "symbol.h"
#include "stdio.h"
#include <stdlib.h>
#include <assert.h>

Type_ _ERROR_TYPE,_INT_TYPE,_FLOAT_TYPE;

TypePtr ERROR_TYPE=&_ERROR_TYPE;
TypePtr INT_TYPE=&_INT_TYPE;
TypePtr FLOAT_TYPE=&_FLOAT_TYPE;


SymbolPtr symbolTable[HASH_SIZE];


void initSymbolTable()
{
    ERROR_TYPE->kind=ERROR;
    INT_TYPE->kind=BASIC;
    INT_TYPE->basic=BASIC_INT;

    FLOAT_TYPE->kind=BASIC;
    FLOAT_TYPE->basic=BASIC_FLOAT;

    for (int i = 0; i < HASH_SIZE; i++)
        symbolTable[i] = NULL;
}

bool insertSymbol(char *name, TypePtr type)
{
    SymbolPtr f = (SymbolPtr)malloc(sizeof(Symbol_));
    f->name = name;
    f->next = NULL;
    f->type = type;

    if (searchSymbol(f->name))
    {
        //fprintf(stderr,"error, %s is exist\n", f->name);
        return false;
    }
    unsigned int val = hash_pjw(f->name);
    if (symbolTable[val] == NULL)
    {
        symbolTable[val] = f;
    }
    else
    {
        f->next = symbolTable[val];
        symbolTable[val] = f;
    }
    return true;
}

SymbolPtr searchSymbol4StructField(char *name){
    for(int i=0;i<HASH_SIZE;i++){
        SymbolPtr temp = symbolTable[i];
        while (temp != NULL)
        {
            SymbolPtr symbol = searchNameInGivenSymbol(name, temp);
            if (symbol!=NULL)
            {
                return symbol;
            }
            temp = temp->next;
        }
    }
    return NULL;
}

SymbolPtr searchSymbol(char *name)
{
    unsigned int val = hash_pjw(name);
    SymbolPtr temp = symbolTable[val];
    while (temp != NULL)
    {
        SymbolPtr symbol = searchNameInGivenSymbol(name, temp);
        if (symbol!=NULL)
        {
            return symbol;
        }
        temp = temp->next;
    }
    return NULL;
}

SymbolPtr searchNameInGivenSymbol(char *name, SymbolPtr des) {
    if(strcmp(des->name, name)==0)
        return des;
    FieldListPtr temp;
    switch (des->type->kind)
    {
        case BASIC:
        case ARRAY:
            break;
        case STRUCTURE:
            temp = des->type->structure->head;
            while(temp){
                SymbolPtr t = searchNameInGivenSymbol(name, temp);
                if(t != NULL)
                    return t;
                temp=temp->next;
            }
            break;
        case FUNCTION:
            temp = des->type->function.params;
            while(temp != NULL){
                SymbolPtr t = searchNameInGivenSymbol(name, temp);
                if(t != NULL)
                    return t;
                temp = temp->next;
            }
            break;
        default:
            break;
    }
    return NULL;
}



FieldListPtr searchStructByNameInOneDepth(char *name, TypePtr spec) {
    assert(spec->kind==STRUCTURE);

    FieldListPtr a=spec->structure->head;

    while(a!=NULL){
        if(strcmp(a->name,name)==0)
            return a;
        a=a->next;
    }
    return NULL;
}


bool typeEqual(TypePtr src, TypePtr des){
    if(src==NULL && des==NULL)
        return true;
    if(src==NULL || des == NULL)
        return false;
    if(src->kind==ERROR||des->kind==ERROR)
        return false;
    if(src->kind != des->kind)
        return false;
    FieldListPtr head1 ;
    FieldListPtr head2 ;
    switch (src->kind){
        case BASIC:
            return src->basic == des->basic?true:false;
        case ARRAY:
            return typeEqual(src->array.elem, des->array.elem);
        case STRUCTURE:
            head1= src->structure->head;
            head2= des->structure->head;
            while(head1 != NULL){
                if(!typeEqual(head1->type, head2->type))
                    return false;
                head1 = head1->next;
                head2 = head2->next;
            }
            return true;
        case FUNCTION:
            assert(0);
        default:assert(0);
    }
    return true;
}

unsigned int hash_pjw(char *name)
{
    // return 0;
    unsigned int val = 0, i;
    for (; *name; ++name)
    {
        val = (val << 2) + *name;
        if (i = val & ~0x3fff)
            val = (val ^ (i >> 12)) & 0x3fff;
    }
    return val;
}


void printSymbolTabel()
{
    for (int i = 0; i < HASH_SIZE; i++)
    {
        SymbolPtr temp = symbolTable[i];
        int j = 0;
        while (temp != NULL)
        {
            printf("----------------\n");
            printf("[%d][%d] %s ", i, j, temp->name);
            void printTypePtr(TypePtr ptr);
            printTypePtr(temp->type);
            printf("\n");
            temp = temp->next;
            j++;
        }
    }
}

void printTypePtr(TypePtr ptr)
{
    switch (ptr->kind)
    {
    case BASIC:
        //            printf("BASIC");
        if (ptr->basic == BASIC_INT)
            printf("int ");
        else
            printf("float ");
        printf("\n");
        break;
    case STRUCTURE:
        printf("struct :\n");
        FieldListPtr head = ptr->structure->head;
        while (head != NULL)
        {
            printTypePtr(head->type);
            printf("\t%s\n", head->name);
            head = head->next;
        }
        break;
    case ARRAY:
        printf("array\n");
        printf("[%d]", ptr->array.size);
        printTypePtr(ptr->array.elem);
        break;
    case FUNCTION:
        printf("func\n");
        FieldListPtr headPara = ptr->function.params;
        while (headPara != NULL)
        {
            printTypePtr(headPara->type);
            printf("\t%s\n", headPara->name);
            headPara = headPara->next;
        }
        break;
    default:
        assert(0);
    }
}