import re

def getHandle(unitName):
    return "semiHandle%s" % unitName

def getENUM(unitName):
    return "ENUM_SYN_%s" % unitName

def assertSth(something):
    return  "assert(%s)" % something

if __name__=="__main__":
    file=open("a.txt","r");
    output=open("out.c","w");

    strs=file.readlines();
    strs=list(filter(lambda x:not "//" in x and not "error" in x,strs))
    strs=list(map(lambda x:x.strip(),strs))
    nowDes=None
    for each in strs:
        each=str(each)
        if ':' in each:
            if not nowDes==None:
                output.write("\telse {\n \t\t %s;\n\t}\n}" % assertSth("0"))  # end of function
            nowDes=each.split(":")[0]
            each=each.split(":")[1]
            nowDes=nowDes.strip()

            each = each.split("{")[0]
            eachUnits = each.split()
            temp = ""
            i=0
            for eachUnit in eachUnits[:-1]:
                temp += "des->children[%d]->enumNodeType==%s && " % (i,getENUM(eachUnit))
                i+=1
            temp += "des->children[%d]->enumNodeType==%s"% (i,getENUM(eachUnits[-1]))
            output.write("\nvoid %s (Node * des) {\n\tif (%s){\n"
                         "\t\t%s\n" % (getHandle(nowDes),temp,assertSth("des->nrChildren==%d" % len(eachUnits))))

            output.write("\t}\n")

        if each.startswith("|"):
            each=each[1:]
            each = each.split("{")[0]
            eachUnits = each.split()
            temp=""
            if len(eachUnits)==0: # epsilon
                temp="\telse if (des->nrChildren==0) { // epsilon\n"
                output.write(temp)
            else:
                i=0
                for eachUnit in eachUnits[:-1]:
                    temp+="des->children[%d]->enumNodeType==%s && " % (i,getENUM(eachUnit))
                    i+=1
                temp+="des->children[%d]->enumNodeType==%s"% (i,getENUM(eachUnits[-1]))
                output.write("\telse if(%s) {"
                             "\n\t\t%s;\n" % (temp,assertSth("des->nrChildren==%d" % len(eachUnits)))) # assert nr of children
                i=0
                for eachUnit in eachUnits:
                    output.write("\t\t%s(des->children[%d])\n" % (getHandle(eachUnit),i))
                    i+=1
            output.write("\t}\n") # end of else if

    output.close()