import re

allStr = ""
lexicalMap = {
    "STRUCT": "struct",
    "RETURN": "return",
    "IF": "if",
    "ELSE": "else",
    "WHILE": "while",
    "SEMI": ";",
    "COMMA": ",",
    "ASSIGNOP": "=",
    "RELOP": "relational  operator: > , < , >= , <= , == , !=",
    "PLUS": "+",
    "MINUS": "-",
    "STAR": "*",
    "DIV": "/",
    "AND": "&&",
    "OR": "||",
    "DOT": ".",
    "TYPE": "specifier int or float",
    "LP": "(",
    "RP": ")",
    "LB": "[",
    "RB": "]",
    "LC": "{",
    "RC": "}",
    "FLOAT": "a float number",
    "INT": "an integer number",
    "ID": "an identifier",
    "$end": "end of file",
    "NOT": "!"
}
stateExpectStr = []
with open("syntax.output", "r") as f:
    for eachline in f.readlines():
        if eachline != "\n":
            allStr = allStr + eachline.strip() + "\n"
    stateGroup = allStr.split("State")
    stateGroup.remove(stateGroup[0])
    print("[Generate Expect] # of State : %d" % len(stateGroup))
    i=0
    for eachStateStr in stateGroup:
        expectList = (re.findall(r"(.*?)\s*shift", eachStateStr))
        if expectList.count("error") != 0:
            expectList.remove("error")
        expectList = list(map(lambda x: lexicalMap[x], expectList))
        expectStr = ""
        if len(expectList) != 0:
            expectStr = "\033[0;42m %s \033[0m" % expectList[0]
            for each in expectList[1:]:
                expectStr += "\033[0;31m OR \033[0;42m %s \033[0m" % each
                # expectStr += " OR "+each
        stateExpectStr.append(expectStr)
        # print("--------------------%d--------------------"%i)
        # print(stateExpectStr)
        i=i+1
with open("stateExpectStrTb.c", "w") as f:
    temp = "#include <stddef.h>\nchar *stateExpectStrTb[]={\""
    temp += stateExpectStr[0]
    temp += "\""
    for eachStr in stateExpectStr[1:]:
        temp += ",\n\t\""
        temp += eachStr
        temp += "\""
    temp += "};"
    temp=temp.replace("\"\"","NULL")
    f.write(temp)
