#ifndef _SYMBOL_H_
#define _SYMBOL_H_

#include "stdio.h"
#include "string.h"

#define HASH_SIZE 16384
#define MAX_NAME_LENTH 100

typedef struct Type_ *TypePtr;
typedef struct FieldList_ *FieldListPtr, *SymbolPtr;
typedef enum { BASIC_INT,
               BASIC_FLOAT } BASIC_TYPE;
typedef enum { false,
               true } bool;
typedef enum {
    BASIC,
    ARRAY,
    STRUCTURE,
    FUNCTION,
    ERROR
} Type_Kind;
typedef struct Type_
{
    Type_Kind kind;
    union {
        //基本类型
        BASIC_TYPE basic;

        //数组类型信息包括元素类型与数组大小构成
        struct
        {
            TypePtr elem;
            int size;
        } array;

        //结构体类型信息是一个链表
        FieldListPtr structure;

        //函数类型信息由类型、参数、参数个数构成
        struct
        {

            TypePtr retType;
            FieldListPtr params;
            int nrParams;
        } function;
    };
} Type_;

typedef struct FieldList_
{
    char *name;   // 域的名字
    TypePtr type; // 域的类型
    union {
        FieldListPtr head;
        FieldListPtr next; // 下一个域
    };
} FieldList_, Symbol_;

void initSymbolTable();
bool insertSymbol(char *name, TypePtr type);
SymbolPtr searchSymbol(char *name);
unsigned int hash_pjw(char *name);
void printSymbolTabel();
SymbolPtr searchNameInGivenSymbol(char *name, SymbolPtr des);
bool typeEqual(TypePtr src, TypePtr des);
FieldListPtr searchStructByNameInOneDepth(char * name,TypePtr spec);
SymbolPtr searchSymbol4StructField(char *name);

extern TypePtr ERROR_TYPE,INT_TYPE,FLOAT_TYPE;
extern Type_ _ERROR_TYPE;
#endif
