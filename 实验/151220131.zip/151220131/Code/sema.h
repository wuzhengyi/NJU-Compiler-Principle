#ifndef __SEMA__H__
#define __SEMA__H__
#include "symbol.h"
#include "myTree.h"
// #include "string.h"
// #include "stdio.h"
#include "assert.h"

void semaHandleProgram(Node *des);
void semaHandleExtDefList(Node *des);
void semaHandleExtDef(Node *des);
void semaHandleExtDecList(Node *des, TypePtr specifier);
bool semaHandleOptTag(Node *des, TypePtr specifier);
TypePtr semaHandleSpecifier(Node *des);
void semaHandleStructSpecifier(Node *des, TypePtr specifier);
void semaHandleTag(Node *des, TypePtr specifier);
void semaHandleVarDec4Struct(Node *des, TypePtr subfieldType, TypePtr structSpecifier);
void semaHandleFunDec4Define(struct node_t *des, TypePtr pType_);
void semaHandleVarList(struct node_t *des, TypePtr funTypePtr);
void semaHandleParamDec(struct node_t *des, TypePtr funcTypePtr);
void semaHandleCompSt(Node *des);
void semaHandleStmtList(Node *des);
void semaHandleStmt(Node *des);
void semaHandleDefList4Struct(Node *des, TypePtr specifier);
void semaHandleDef4Struct(Node *des, TypePtr specifier);
void semaHandleDecList4Struct(Node *des, TypePtr subfieldType, TypePtr specifier);
void semaHandleDec4Struct(Node *des, TypePtr subfieldType, TypePtr specifier);
TypePtr semaHandleExp(Node *des);
void semaHandleArgs(Node *des, FieldListPtr * params, int i,int nrParams);
void semaHandleArgsWrapper(Node *des, FieldListPtr params,int nrParams);
#define MAX_FUNCTION_PARAMS_NUM 50
#endif
