#! /bin/bash
for i in `ls Test | sort -n`; 
do 
    echo ------------------- $i -----------------------
    ./Code/parser Test/$i
done